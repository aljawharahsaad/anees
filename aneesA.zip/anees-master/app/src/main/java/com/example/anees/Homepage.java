package com.example.anees;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;


public class Homepage extends AppCompatActivity {

    Button homeButton;
    Button personalButton;
    ImageView logo;
    ImageView panelf1;
    ImageView panelf2;
    ImageView background;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        logo = findViewById(R.id.logo);
        panelf1 = findViewById(R.id.panelf1);
        panelf2 = findViewById(R.id.panelf2);
        background = findViewById(R.id.background);

        setContentView(R.layout.activity_homepage);

        //Implement clickable first button
        homeButton = findViewById(R.id.homeButton);
        homeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new
                        Intent(Homepage.this, MapsActivity.class);
                startActivity(intent);
            }
        });

        //Implement clickable second button
        personalButton = findViewById(R.id.personalButton);
        personalButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new
                        Intent(Homepage.this, Profile.class);
                startActivity(intent);
            }
        });



    }
}


