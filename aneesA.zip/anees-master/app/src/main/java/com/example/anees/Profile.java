package com.example.anees;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;

public class Profile extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
    }

    public void onSendMessage (View view) {

        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        String chooserTitle = getString(R.string.chooser);
        startActivity(intent);


    }

    public boolean onOptionsItemSelected(@NonNull MenuItem item){
        Intent intent = new Intent(getApplicationContext(), Homepage.class);
        startActivityForResult(intent,0);
        return true;
    }

}