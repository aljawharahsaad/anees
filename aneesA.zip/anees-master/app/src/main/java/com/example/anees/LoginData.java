package com.example.anees;

public class LoginData {
    private String password;
    private String User;

    public String getPassword() {
        return password;
    }

    public String getUser() {
        return User;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setUser(String user) {
        User = user;
    }
}


